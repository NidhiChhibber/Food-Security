package com.example.research_app.DonorActivities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.FrameLayout;

import com.example.research_app.ConsumerActivities.ConsumerBaseDrawerActivity;
import com.example.research_app.CosumerClasses.ConsumerDashAdapter;
import com.example.research_app.CosumerClasses.ConsumerDashItemList;
import com.example.research_app.R;

import java.util.ArrayList;
import java.util.List;



public class DonorHome extends BaseDrawerActivity
{
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        FrameLayout contentFrameLayout = (FrameLayout) findViewById(R.id.fragment_container);
        getLayoutInflater().inflate(R.layout.activity_donor_home, contentFrameLayout);
        String titles[] = {"Search Consumer", "Search consumer by location","Search consumer by item name"};
        String descriptions[] ={"Click here to search user ", "Click here to search for user requests based on location", "Click here to search for user requests based on name of items required by users"};
        int pictureList[] = {R.drawable.orange_bluebackground,R.drawable.orange_bluebackground,R.drawable.orange_bluebackground};
        mRecyclerView = findViewById(R.id.recycler_view_donor_2);

        List<ConsumerDashItemList> consumerDashItemListList = new ArrayList<>();
        for (int i = 0; i < titles.length; ++i)
        {
            consumerDashItemListList.add(new ConsumerDashItemList(i,titles[i],descriptions[i],pictureList[i]));
        }
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new DonorHomeAdapter(consumerDashItemListList, this);
        mRecyclerView.setAdapter(mAdapter);
    }
}
