package com.example.research_app.ui;

public class CartItems
{

}
