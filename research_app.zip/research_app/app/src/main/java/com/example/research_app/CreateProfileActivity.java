package com.example.research_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.example.research_app.ConsumerActivities.ConsumerDash;
import com.example.research_app.DonorActivities.DonorDash;
import com.example.research_app.DonorActivities.DonorHome;
import com.example.research_app.DonorActivities.SearchActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.vikktorn.picker.City;
import com.vikktorn.picker.CityPicker;
import com.vikktorn.picker.Country;
import com.vikktorn.picker.CountryPicker;
import com.vikktorn.picker.OnCityPickerListener;
import com.vikktorn.picker.OnCountryPickerListener;
import com.vikktorn.picker.OnStatePickerListener;
import com.vikktorn.picker.State;
import com.vikktorn.picker.StatePicker;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class CreateProfileActivity extends AppCompatActivity implements OnStatePickerListener, OnCountryPickerListener, OnCityPickerListener {

    private ImageView avatar;
    private EditText nameEF,addressEF,aboutEF;
    private Button finishB, pickStateButton, pickCountry, pickCity, selectedCityBtn;
    private FirebaseAuth mAuth;
    private RadioGroup radioUserType;
    private RadioButton userTypeButton;
    String userType,selectedCountry, selectedState, selectedCity ;
    public static int countryID, stateID;
    private TextView stateNameTextView, countryName, cityName;
    private CountryPicker countryPicker;
    private StatePicker statePicker;
    private CityPicker cityPicker;
    public static List<State> stateObject;
    public static List<City> cityObject;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_profile);
        avatar = findViewById(R.id.avatar);
        nameEF = findViewById(R.id.name);
        finishB= findViewById(R.id.finish);
        radioUserType = findViewById(R.id.radioUserType);
        aboutEF = findViewById(R.id.consumerAbout);
        initView();
        try {
            getStateJson();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            getCityJson();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        countryPicker = new CountryPicker.Builder().with(this).listener(this).build();
        setListener();
        setCountryListener();
        setCityListener();

        finishB.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                int selectedId=radioUserType.getCheckedRadioButtonId();
                aboutEF.setVisibility(View.VISIBLE);
                userTypeButton=(RadioButton)findViewById(selectedId);
                userType = userTypeButton.getText().toString();
                updateProfile();
            }
        });
    }

    protected void updateProfile()
    {
        mAuth = FirebaseAuth.getInstance();
        String user_name = nameEF.getText().toString();
        FirebaseUser user = mAuth.getCurrentUser();
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final String Uid = user.getUid();
        try {
            DatabaseReference userRef = database.getReference("users");
            String email = user.getEmail();
            UserDetailsClass newUser = new UserDetailsClass();
            newUser.setName(user_name.toLowerCase());
            newUser.setCountry(selectedCountry.toLowerCase());
            newUser.setState(selectedState.toLowerCase());
            newUser.setCity(selectedCity.toLowerCase());
            newUser.setEmail(email);
            newUser.setUid(Uid);


            if(userType.equals("Register to donate"))
            {
                newUser.setAccType("donor");
                //myRef.child(Uid).child("accType").setValue("Donor");

                userRef.child(Uid).child("accountType").setValue("donor");
                DatabaseReference myRef = database.getReference("donors");
                myRef.child(Uid).setValue(newUser);
                Intent intent = new Intent(CreateProfileActivity.this, DonorHome.class);
                startActivity(intent);
            }
            else if ( userType.equals("Register to request donation"))
            {
                userRef.child(Uid).child("accountType").setValue("consumer");
                String aboutC = aboutEF.getText().toString().toLowerCase();
                newUser.setDescription(aboutC);
                newUser.setAccType("consumer");
                DatabaseReference myRef = database.getReference("consumers");
                myRef.child(Uid).setValue(newUser);
                Intent intent = new Intent(CreateProfileActivity.this, ConsumerDash.class);
                startActivity(intent);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void initView(){
        //Buttons
        pickStateButton = (Button) findViewById(R.id.pickStateBtn);
        pickStateButton.setVisibility(android.view.View.INVISIBLE);
        pickCountry = (Button) findViewById(R.id.pickCountryBtn);
        pickCity = (Button) findViewById(R.id.pickCityBtn);
        pickCity.setVisibility(android.view.View.INVISIBLE);
        countryName = (TextView) findViewById(R.id.countryNameTV);
        stateNameTextView = (TextView) findViewById(R.id.stateNameTV);
        stateNameTextView.setVisibility(android.view.View.INVISIBLE);
        cityName = (TextView) findViewById(R.id.cityNameTV);
        cityName.setVisibility(android.view.View.INVISIBLE);
        stateObject = new ArrayList<>();
        cityObject = new ArrayList<>();
    }
    private void setListener()
    {
        pickStateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                statePicker.showDialog(getSupportFragmentManager());
            }
        });
    }

    //SET COUNTRY LISTENER
    private void setCountryListener() {
        pickCountry.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                countryPicker.showDialog(getSupportFragmentManager());
            }
        });
    }
    //SET CITY LISTENER
    private void setCityListener() {
        pickCity.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                cityPicker.showDialog(getSupportFragmentManager());
            }
        });
    }
    // ON SELECTED COUNTRY ADD STATES TO PICKER
    @Override
    public void onSelectCountry(Country country) {
        // get country name and country ID
        countryName.setText(country.getName());
        countryID = country.getCountryId();
        statePicker.equalStateObject.clear();
        cityPicker.equalCityObject.clear();

        //set state name text view and state pick button invisible
        pickStateButton.setVisibility(android.view.View.VISIBLE);
        stateNameTextView.setVisibility(android.view.View.VISIBLE);
        stateNameTextView.setText("Region");
        cityName.setText("City");


        // GET STATES OF SELECTED COUNTRY
        for(int i = 0; i < stateObject.size(); i++) {
            // init state picker
            statePicker = new StatePicker.Builder().with(this).listener(this).build();
            State stateData = new State();
            if (stateObject.get(i).getCountryId() == countryID) {

                stateData.setStateId(stateObject.get(i).getStateId());
                stateData.setStateName(stateObject.get(i).getStateName());
                stateData.setCountryId(stateObject.get(i).getCountryId());
                stateData.setFlag(country.getFlag());
                statePicker.equalStateObject.add(stateData);
            }
        }
        selectedCountry = country.getName();
    }
    // ON SELECTED STATE ADD CITY TO PICKER
    @Override
    public void onSelectState(State state) {
        pickCity.setVisibility(android.view.View.VISIBLE);
        cityName.setVisibility(android.view.View.VISIBLE);
        cityName.setText("City");
        cityPicker.equalCityObject.clear();

        stateNameTextView.setText(state.getStateName());
        stateID = state.getStateId();



        for(int i = 0; i < cityObject.size(); i++) {
            cityPicker = new CityPicker.Builder().with(this).listener(this).build();
            City cityData = new City();
            if (cityObject.get(i).getStateId() == stateID) {
                cityData.setCityId(cityObject.get(i).getCityId());
                cityData.setCityName(cityObject.get(i).getCityName());
                cityData.setStateId(cityObject.get(i).getStateId());

                cityPicker.equalCityObject.add(cityData);
            }
        }
        selectedState = state.getStateName();

    }
    // ON SELECTED CITY
    @Override
    public void onSelectCity(City city) {
        selectedCity = city.getCityName();
        cityName.setText(selectedCity);

    }
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
    // GET STATE FROM ASSETS JSON
    public void getStateJson() throws JSONException {
        String json = null;
        try {
            InputStream inputStream = getAssets().open("states.json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            json = new String(buffer, "UTF-8");

        } catch (IOException e) {
            e.printStackTrace();
        }


        JSONObject jsonObject = new JSONObject(json);
        JSONArray events = jsonObject.getJSONArray("states");
        for (int j = 0; j < events.length(); j++) {
            JSONObject cit = events.getJSONObject(j);
            State stateData = new State();

            stateData.setStateId(Integer.parseInt(cit.getString("id")));
            stateData.setStateName(cit.getString("name"));
            stateData.setCountryId(Integer.parseInt(cit.getString("country_id")));
            stateObject.add(stateData);
        }
    }
    // GET CITY FROM ASSETS JSON
    public void getCityJson() throws JSONException {
        String json = null;
        try {
            InputStream inputStream = getAssets().open("cities.json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            json = new String(buffer, "UTF-8");

        } catch (IOException e) {
            e.printStackTrace();
        }


        JSONObject jsonObject = new JSONObject(json);
        JSONArray events = jsonObject.getJSONArray("cities");
        for (int j = 0; j < events.length(); j++) {
            JSONObject cit = events.getJSONObject(j);
            City cityData = new City();

            cityData.setCityId(Integer.parseInt(cit.getString("id")));
            cityData.setCityName(cit.getString("name"));
            cityData.setStateId(Integer.parseInt(cit.getString("state_id")));
            cityObject.add(cityData);
        }
    }
}
