package com.example.research_app;

import android.widget.ImageView;

public class UserDetailsClass
{
    public String name,email,uid,country,state,city,accType,profilePicture,description;

    public UserDetailsClass()
    {

    }

    public void setName(String name){this.name= name;}
    public void setCountry(String country){this.country = country;}
    public void setState(String state){this.state = state;}
    public void setCity(String city){this.city = city;}
    public void setEmail(String email){this.email=email;}
    public void setUid(String uid){this.uid= uid;}
    public void setAccType(String accType){this.accType= accType;}
    public void setDescription(String desc) {this.description=desc;}
    public String getName(){return name;}
    public String getCountry(){return this.country;}
    public String getState(){return this.state;}
    public String getCity(){return this.city;}
    public String getEmail(){return email;}
    public String getUid(){return uid;}
    public String getAccType(){return accType;}
    public String getDescription(){ return this.description;}


}
