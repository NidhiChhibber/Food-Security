package com.example.research_app.ConsumerActivities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.example.research_app.CosumerClasses.ConsumerDashItemList;
import com.example.research_app.CosumerClasses.ConsumerDashAdapter;
import com.example.research_app.DonorActivities.BaseDrawerActivity;
import com.example.research_app.R;

import java.util.ArrayList;
import java.util.List;

public class ConsumerDash extends ConsumerBaseDrawerActivity
{
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        FrameLayout contentFrameLayout = (FrameLayout) findViewById(R.id.consumerFragmentContainer);
        getLayoutInflater().inflate(R.layout.activity_consumer_dash, contentFrameLayout);
        String titles[] = {"Edit Public Profile","Request item", "Remove item"};
        String descriptions[] ={"Click here to edit profile visible to Donors", "Click here to request for a new item",
                "Click here to remove a requested item"};
        int pictureList[] = {R.drawable.edit_profile_icon,R.drawable.orange_bluebackground,R.drawable.orange_bluebackground};
        mRecyclerView = findViewById(R.id.recycler_view_2);

        List<ConsumerDashItemList> consumerDashItemListList = new ArrayList<>();
        for (int i = 0; i < titles.length; ++i)
        {
            consumerDashItemListList.add(new ConsumerDashItemList(i,titles[i],descriptions[i],pictureList[i]));
        }
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new ConsumerDashAdapter(consumerDashItemListList, this);
        mRecyclerView.setAdapter(mAdapter);
    }
}
