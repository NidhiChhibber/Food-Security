package com.example.research_app.DonorActivities;

import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.research_app.R;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DonorProfile extends BaseDrawerActivity
{   private ImageView avatar;
    private ImageButton editName, editAddress;
    private TextView userEmail, userType;
    EditText userName, userAddress;
    private FirebaseAuth mAuth;
    Button saveBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        FrameLayout contentFrameLayout = (FrameLayout) findViewById(R.id.fragment_container); //Remember this is the FrameLayout area within your activity_main.xml
        getLayoutInflater().inflate(R.layout.activity_donor_profile, contentFrameLayout);
        saveBtn =findViewById(R.id.saveBtn);
        saveBtn.setVisibility(View.INVISIBLE);
        userName = findViewById(R.id.nameET);
        userName.setEnabled(false);
        userAddress = findViewById(R.id.addressET);
        userAddress.setEnabled(false);
        userEmail = findViewById(R.id.emailET);
        userType = findViewById(R.id.accountTypeET);
        editName = findViewById(R.id.updateNameImgBtn);
        editName.setVisibility(View.INVISIBLE);
        editAddress = findViewById(R.id.updateAddressImgBtn);
        editAddress.setVisibility(View.INVISIBLE);

    }

    protected void onStart()
    {
        super.onStart();
        getUserData();
        editName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                editBtnClicked(userName);
            }
        });
        editAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                editBtnClicked(userAddress);

            }
        });
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean check = checkTextFields();
                if(check == true)
                {

                }
                else
                {

                }
            }
        });

    }
    protected boolean checkTextFields()
    {
        if(userName.getText().equals(""))
        {
            TextInputLayout til = (TextInputLayout) findViewById(R.id.text_input_layout);
            til.setError("You need to enter a name");
            return false;
        }
        else if (userAddress.getText().equals(""))
        {
            return false;
        }
        else
            return true;
    }
    protected  void editBtnClicked(EditText btnName)
    {
        btnName.setEnabled(true);
        btnName.setText("");
        saveBtn.setVisibility(View.VISIBLE);
    }

    protected void getUserData()
    {
        mAuth = FirebaseAuth.getInstance();
        final FirebaseUser user = mAuth.getCurrentUser();
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final String userID = user.getUid();
        Log.d("userID", ""+userID);
        DatabaseReference donorDetailsRef = database.getReference("donors/"+userID);
        donorDetailsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {

                String name = (String) dataSnapshot.child("name").getValue();
                name = name.substring(0, 1).toUpperCase() + name.substring(1);
                String email = (String) dataSnapshot.child("email") .getValue();
                String state = (String) dataSnapshot.child("state").getValue();
                state = state.substring(0, 1).toUpperCase() + state.substring(1);
                String country = (String) dataSnapshot.child("country").getValue();
                country = country.substring(0, 1).toUpperCase() + country.substring(1);
                String city = (String) dataSnapshot.child("city").getValue();
                city = city.substring(0, 1).toUpperCase() + city.substring(1);
                String type = (String) dataSnapshot.child("accType").getValue();
                type = type.substring(0, 1).toUpperCase() + type.substring(1);
                userName.setText(name);
                userAddress.setText(city+","+state+","+country);
                userEmail.setText(email);
                userType.setText(type);
                editName.setVisibility(View.VISIBLE);
                editAddress.setVisibility(View.VISIBLE);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
