package com.example.research_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;

import java.util.HashMap;

public class RegistrationActivity extends AppCompatActivity
{

    private EditText emailEF, passwordEF;
    private Button regB;
    private ImageButton regGoogle;
    private FirebaseAuth mAuth;
    private TextView tvExistingUser;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        emailEF = findViewById(R.id.registerEmail);
        passwordEF = findViewById(R.id.registerPassword);
        regB = findViewById(R.id.registerButton);
        tvExistingUser = findViewById(R.id.tvExistingUser);
        mAuth = FirebaseAuth.getInstance();
        regB.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                registerUser();
            }
        });
        tvExistingUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegistrationActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    protected void registerUser()
    {
        String strEmail, strPassword;
        strEmail = emailEF.getText().toString();
        strPassword = passwordEF.getText().toString();
        if(!validateEntry(strEmail, strPassword)) return;
        mAuth.createUserWithEmailAndPassword(strEmail, strPassword).addOnCompleteListener(this, new OnCompleteListener<AuthResult>()
        {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task)
            {
               if(task.isSuccessful())
               {
                   FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                   user.sendEmailVerification()
                           .addOnCompleteListener(new OnCompleteListener<Void>() {
                               @Override
                               public void onComplete(@NonNull Task<Void> task) {
                                   if (task.isSuccessful())
                                   {
                                       // email sent
                                       Log.d("Status", "EMAIL SENT");
                                       FirebaseAuth.getInstance().signOut();
                                       startActivity(new Intent(RegistrationActivity.this, LoginActivity.class));
                                       finish();

                                   }
                                   else
                                   {
                                       // email not sent, so display message and restart the activity or do whatever you wish to do
                                       Log.d("Status", "EMAIL NOT SENT");
                                       //restart this activity
                                       overridePendingTransition(0, 0);
                                       finish();
                                       overridePendingTransition(0, 0);
                                       startActivity(getIntent());

                                   }
                               }
                           });

                   Toast.makeText(getApplicationContext(),"Registration Successful", Toast.LENGTH_LONG).show();
                   //Intent intent = new Intent(RegistrationActivity.this, CreateProfileActivity.class);
                   //startActivity(intent);
               }
               else
               {
                   FirebaseAuthException error = (FirebaseAuthException)task.getException();
                   Toast.makeText(getApplicationContext(), "Registration Failed: "+error.getMessage(), Toast.LENGTH_SHORT).show();
                   return;
               }
            }
        });

    }


    protected boolean validateEntry(String strEmail, String strPassword)
    {

        if(TextUtils.isEmpty(strEmail))
        {
            Toast.makeText(getApplicationContext(), "Email-Id field can not be empty", Toast.LENGTH_LONG).show();
            return false;
        }
        if(TextUtils.isEmpty(strPassword))
        {
            Toast.makeText(getApplicationContext(), "Password field can not be empty", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

}
