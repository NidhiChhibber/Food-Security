package com.example.research_app.ConsumerActivities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.research_app.CosumerClasses.RequestItemsClass;
import com.example.research_app.R;
import com.example.research_app.ui.RequiredItemsList;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ConsumerRequestItemActivity extends AppCompatActivity {
    EditText itemNameET,itemDateET,itemQuantityET,itemUnitsET;
    Button putRequestBtn;
    String itemName,itemDate,itemUnits, userName, userCity, userCountry, userState, userDescription, freeFormString="";
    int itemQuantity;
    private FirebaseAuth mAuth;
    final FirebaseDatabase db = FirebaseDatabase.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consumer_request_item);
        itemDateET = findViewById(R.id.consumerReqItemDate);
        itemNameET = findViewById(R.id.consumerReqItemName);
        itemQuantityET = findViewById(R.id.consumerReqItemQuantity);
        putRequestBtn = findViewById(R.id.requestBtn);
        itemUnitsET = findViewById(R.id.consumerReqItemUnits);

        putRequestBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                updateUserRequestDatabase();
            }
        });

    }

    public void updateUserRequestDatabase()
    {
        mAuth = FirebaseAuth.getInstance();
        itemName = itemNameET.getText().toString().toLowerCase();
        itemDate = itemDateET.getText().toString();
        itemQuantity = Integer.parseInt(itemQuantityET.getText().toString());
        itemUnits = itemUnitsET.getText().toString();

        FirebaseUser user = mAuth.getCurrentUser();
        final DatabaseReference itemDetailsRef = db.getReference("consumerRequests");
        final String uId = user.getUid();
        RequiredItemsList newRequest = new RequiredItemsList();
        newRequest.setName(itemName);
        newRequest.setDate(itemDate);
        newRequest.setQuantity(itemQuantity);
        newRequest.setUnits(itemUnits);
        itemDetailsRef.child(uId).child(itemName).setValue(newRequest);
        Toast.makeText(getApplicationContext(),"Put new request"+itemNameET, Toast.LENGTH_LONG).show();

        Toast.makeText(getApplicationContext(),"Put new request", Toast.LENGTH_LONG).show();
        final DatabaseReference myRef2 = db.getReference("consumers/"+uId);
        myRef2.child("items").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if (dataSnapshot.hasChild("name"))
                {

                }
                else
                {
                    myRef2.child("items").child(itemName).setValue(itemName);
                    setFreeFormString();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void setFreeFormString()
    {
        FirebaseUser user = mAuth.getCurrentUser();
        final String uId = user.getUid();
        final DatabaseReference consumerDetailRef = db.getReference("consumers/"+uId);
        consumerDetailRef.addValueEventListener(new ValueEventListener()

        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                userName = (String) dataSnapshot.child("name").getValue();
                userCountry = (String) dataSnapshot.child("country").getValue();
                userState = (String) dataSnapshot.child("state").getValue();
                userCity = (String) dataSnapshot.child("city").getValue();
                userDescription = (String) dataSnapshot.child("description").getValue();
                freeFormString = freeFormString+" "+ userName +" "+userCountry+" "+ userState+ " "+ userCity+ " "+userDescription;
                DatabaseReference requestRef = db.getReference("consumerRequests/" + uId);
                requestRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                    {
                        if (dataSnapshot.exists()) {

                            for (DataSnapshot ds : dataSnapshot.getChildren())
                            {
                                RequiredItemsList post = (RequiredItemsList) ds.getValue(RequiredItemsList.class);
                                freeFormString = freeFormString+" "+post.getName();

                            }

                        }
                        db.getReference("consumers/"+uId).child("string").setValue(freeFormString);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError)
                    {

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
